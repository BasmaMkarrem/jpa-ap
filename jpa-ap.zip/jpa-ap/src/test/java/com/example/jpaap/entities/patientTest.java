package com.example.jpaap.entities;

import static org.junit.jupiter.api.Assertions.*;

class patientTest {

}